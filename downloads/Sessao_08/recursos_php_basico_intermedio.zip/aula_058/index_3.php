<?php

// COPIAR, MOVER, RENOMEAR E ELIMINAR FICHEIROS

// Para eliminar um ficheiro, usamos a função unlink
unlink('file_to_delete.nfo');