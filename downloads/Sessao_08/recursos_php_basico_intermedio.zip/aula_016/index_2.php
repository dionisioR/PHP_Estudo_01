<?php

    // DATA TYPES - tipos de dados

    /* 
    Existem outros tipos de dados mais avançados.
    Iremos falar sobre eles mais à frente.

    Tipos compostos
    --------------------------------
    > arrays
    > objects
    > callable
    > iterate

    Tipos especiais
    --------------------------------
    > resource
    > null
    */
