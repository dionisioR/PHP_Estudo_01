<?php

// TRATAMENTO DE DIFERENTES TIPOS DE INPUTS

/*
Vamos ver como são captados os diferentes tipos de
elementos de HTML tradicionalmente usados nos formulários.
Por agora vamos focar apenas os principais e vamos
deixar para outros vídeos o upload de ficheiros e outros tipos
de inputs.
*/