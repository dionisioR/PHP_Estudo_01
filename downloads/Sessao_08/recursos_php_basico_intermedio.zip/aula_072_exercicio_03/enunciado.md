# ENUNCIADO
O ficheiro index.php contém um ciclo que gera, por cada ciclo, dois números aleatórios.
Cria uma função que recebe esses dois números como parâmetros, divide um pelo outro e retorna
o quociente dessa divisão.

CUIDADO: os números aleatórios (randómicos) podem resultar no valor zero.
Uma divisão por zero vai originar um erro.
Se essa situação acontecer, a função deve retornar o valor null

O resultado das operações deve ser apresentado no browser.
Caso o resultado seja igual a null, deve aparecer a frase: 'Divisão por zero'.

Exemplo:
10 : 2 = 5
3 : 0 = Divisão por zero