# ENUNCIADO
O ficheiro index.php contém o início de um formulário onde deves adicionar
um campo de texto e um botão de submissão.

O formulário, quando submetido, será tratado pelo mesmo ficheiro index.php.

No tratamento dos texto submetido, devem ser observadas as seguintes regras:
1. Se o campo de texto vier vazio, o sistema deve apresentar o erro:
"Campo de texto vazio"
2. Se o campo de texto tiver um valor numérico, deve guardar esse valor
num ficheiro dados_numericos.txt e apresentar a informação:
"Valor numérico guardado com sucesso."
3. Se o campo de texto tiver um valor string, deve guardar esse valor
num ficheiro dados_string.txt e apresentar a informação:
"Valor string guardado com sucesso."