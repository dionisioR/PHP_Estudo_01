<?php

echo 'Número da linha em script.php: ' . __LINE__ . '<br>';