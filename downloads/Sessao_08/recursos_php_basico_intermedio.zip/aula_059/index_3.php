<?php

/*

Outras constantes mágicas que iremos falar em outros módulos:

__CLASS__
__TRAIT__
__METHOD__
__NAMESPACE__
ClassName::class

As constantes mágicas mais práticas são __FILE__ e __DIR__

*/