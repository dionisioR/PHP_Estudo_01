<?php

echo '(outros/script.php): ' . __DIR__ . '<br>';