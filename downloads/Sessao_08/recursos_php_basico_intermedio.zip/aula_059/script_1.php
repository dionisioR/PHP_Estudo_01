<?php

echo '(script_1.php): ' . __FILE__ . '<br>';