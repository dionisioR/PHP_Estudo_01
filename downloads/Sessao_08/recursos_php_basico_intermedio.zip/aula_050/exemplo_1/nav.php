<nav style="display: flex; flex-direction: column;">
    <a href="index.php">Início</a>
    <a href="adicionar1.php">Colocar valor 1 na sessão</a>
    <a href="adicionar2.php">Colocar valor 2 na sessão</a>
    <a href="remover1.php">Remover valor 1 na sessão</a>
    <a href="remover2.php">Remover valor 2 na sessão</a>
    <a href="destruir.php">Destruir toda a sessão</a>
</nav>