<?php

// $_COOKIE
/*
    Todos os cookies relacionados com a aplicação e respetivos valores
*/

echo '<pre>';
print_r($_COOKIE);

echo '<br>';
echo ($_COOKIE['PHPSESSID']);