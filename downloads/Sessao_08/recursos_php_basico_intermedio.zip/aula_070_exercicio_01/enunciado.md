# ENUNCIADO
No ficheiro index.php temos um formulário HTML com dois inputs.
O script tratamento.php está vazio.
O objetivo é escrever o código no ficheiro tratamento.php para
alcançar o seguinte resultado:

1. Se o script for acessado diretamente, deve apresentar um erro.
2. Os inputs devem ser validados. Se algum dos valores não for um
valor numérico positivo, volta para o formulário e apresenta esse erro.
3. Sendo os dois inputs valores numéricos, apresentar como resultado
a multiplicação do primeiro pelo segundo e dar o exercício por terminado.