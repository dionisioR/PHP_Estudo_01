<?php

    echo '<pre>';

    /*
        1. Apresentar o cálculo do perímetro de um quadrado com 3.2 metros de lado.

        Resultado: 12.8 m
    */