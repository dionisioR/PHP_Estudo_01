<?php

    echo '<pre>';

    /*
        1. Define a variável "numero" com valor igual a 50
        2. Apresenta a multiplicação desse valor por 4 unidades 

        Resultado: 200
    */