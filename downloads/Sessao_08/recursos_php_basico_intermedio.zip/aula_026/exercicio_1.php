<?php

    echo '<pre>';

    /*
        1. Cria a variável x igual a 100
        2. Cria a variável y igual a 150
        3. Apresenta o resultado da adição das duas variáveis

        Resultado: 250
    */