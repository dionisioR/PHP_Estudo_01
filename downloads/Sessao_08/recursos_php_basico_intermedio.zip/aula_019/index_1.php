<?php

    // FLOATS

    // São números que têm casas decimais.

    $valor1 = 125.5;
    echo $valor1;

    // verificar o tipo de valor
    echo '<br>';
    var_dump($valor1);

    // também podem ser definidos desta forma:
    echo '<br>';
    $valor2 = 1_150.65;
    echo $valor2;