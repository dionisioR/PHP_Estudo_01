<?php

    // também podemos definir constantes com a expressão const

    const NOME = "joao";
    echo NOME;

    /* 
    Esta forma de definição de constantes não é muito utilizada.
    Com define, é possível definir constantes em qualquer parte do código.
    Com const, existem estruturas dentro das quais não podemos criar as constantes.
    */