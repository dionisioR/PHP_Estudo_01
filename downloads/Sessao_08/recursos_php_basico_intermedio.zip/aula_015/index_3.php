<?php

    // o PHP tem as suas próprias constantes.

    echo PHP_VERSION;   
    echo '<br>';

    // e tem um tipo de constantes que são definidas de forma dinâmica.
    // são designadas por constantes mágicas


    echo "Estou a executar este código na linha " . __LINE__;