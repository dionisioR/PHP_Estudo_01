<?php

    // NULL

    $valor = null;
    if(is_null($valor)){
        echo 'É nulo';
    }

    echo '<br>';

    if(empty($valor)){
        echo 'É nulo ou vazio.';
    }