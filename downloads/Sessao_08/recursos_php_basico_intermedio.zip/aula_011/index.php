<?php

echo "Teste de terminal" . PHP_EOL;
print "Novo teste";