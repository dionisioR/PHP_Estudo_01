<?php require_once('header.php') ?>
<h1>Página inicial</h1>
<?php require_once('footer.php') ?>

<?php 
/* 
Os scripts indicados estão numa pasta dentro da pasta onde o index.php existe.
A inclusão vai gerar um erro.
*/
?>