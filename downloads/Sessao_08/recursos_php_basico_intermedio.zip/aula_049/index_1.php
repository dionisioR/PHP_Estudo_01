<?php

/* 
Ainda acerca de inclusão de scripts na nossa aplicação, é muito importante
ter em atenção os caminhos (paths) dos nossos scripts.

IMPORTANTE: Existem várias formas de definir corretamente os caminhos.
Veremos essas formas mais à frente e noutros módulos de PHP.

Vejamos os exemplos.
*/