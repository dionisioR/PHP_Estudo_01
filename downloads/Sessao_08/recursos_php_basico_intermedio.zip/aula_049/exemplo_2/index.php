<?php require_once('estrutura/header.php') ?>
<h1>Página inicial</h1>
<?php require_once('estrutura/footer.php') ?>