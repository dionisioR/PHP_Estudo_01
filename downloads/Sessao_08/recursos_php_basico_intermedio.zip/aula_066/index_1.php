<?php

// VALIDAÇÃO DE FORMULÁRIOS - PARTE 2

/*
A validação do formulário ficou a funcionar corretamente.
A questão é a seguinte:
E se eu quiser apresentar os erros no formulário,
manter os valores que estavam escritos e só apresentar
os dados no caso de já não existir nenhum erro?

IMPORTANTE: Este exercício é mais simples de executar
quando usamos uma framework que já contém mecanismos
programados para facilitar o desenvolvimento destas
operações.

Vamos simplificar com um formulário de login.
*/