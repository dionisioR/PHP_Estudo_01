<?php
    echo 'Esta frase deve aparecer'; // apesar de ter um comentário na mesma linha
    // echo 'Esta frase é para testes';