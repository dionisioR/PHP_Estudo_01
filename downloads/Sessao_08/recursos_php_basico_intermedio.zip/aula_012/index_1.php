<?php

// single-line comment

# single-line comment

/* multi-line
comment */

// ---------------------------------------------------
// Comentários podem entrar aqui
// ---------------------------------------------------

# ----------------------------------------------------
# Comentários podem entrar aqui
# ----------------------------------------------------

/* ---------------------------------------------------
Comentários podem entrar aqui
E nesta segunda linha também 
--------------------------------------------------- */