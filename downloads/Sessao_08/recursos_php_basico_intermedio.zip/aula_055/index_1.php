<?php

/* 
Vamos ver como podemos obter informações sobre ficheiros:
    tamanho do ficheiro
    extenção
    nome do ficheiro

Vamos ver como criar e guardar dados num ficheiro
Vamos fazer um exercício prático muito simples
*/