<?php

    /*
        Constrói a lógica condicional que permite apresentar apenas
        o parágrafo correspondente ao valor da variável $nome
    */

    $nome = 'João';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 4</title>
</head>
<body>
    
    <p>O nome é João</p>
    <p>O nome é Ana</p>
    <p>O nome é Carlos</p>
    <p>É um nome desconhecido</p>

</body>
</html>