<?php
setcookie('theme', 'light', time() + 3600);
header('Location: index.php');