<nav>
    <a href="index.php">Início</a> | 
    <a href="criar_cookie.php">Criar cookie</a> | 
    <a href="remover_cookie.php">Remover cookie</a>
</nav>