<?php

// EXPRESSÃO CONDICIONAL SWITCH

$sexo = 'masculino';

switch ($sexo) {
    case 'masculino':
        # código
        break;
    
    case 'feminino':
        # código
        break;
}


