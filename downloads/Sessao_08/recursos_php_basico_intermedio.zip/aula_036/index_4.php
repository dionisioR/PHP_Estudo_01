<?php

// EXPRESSÃO CONDICIONAL SWITCH

$socio = false;

switch ($socio) {
    case true:
        echo 'É sócio';
        break;
    
    case false:
        echo 'Não é sócio';
        break;
}


