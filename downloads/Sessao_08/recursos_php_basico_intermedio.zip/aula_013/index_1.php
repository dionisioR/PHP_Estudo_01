<?php

    // VARIÁVEIS

    $valor = 100;

    // $valor -> nome da variável
    // = -> operador de atribuição
    // 100 -> valor da variável


    // NOMES DAS VARIÁVEIS
    
    $nome = "joao";
    
    $_idade = 50;
    
    $01teste = 100; // NOK
    
    $nome_da_variavel = "carlos";

    $nome da variavel = "joaquim";  // NOK

    $valor_01 = 1000;

    // case sensitive - 3 variáveis diferentes
    $valor = 100;
    $Valor = 200;
    $VALOR = 300;