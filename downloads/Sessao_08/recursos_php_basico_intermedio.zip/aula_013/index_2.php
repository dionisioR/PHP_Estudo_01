<?php

    // APRESENTAR O VALOR DE UMA VARIÁVEL

    $nome = "joao";
    echo $nome;