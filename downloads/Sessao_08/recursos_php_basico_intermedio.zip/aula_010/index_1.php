<?php
    echo '<h1>PHP</h1>';