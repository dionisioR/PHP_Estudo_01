<?php

echo 'código do script.php' . '<br>';