<?php

// INCLUDE e REQUIRE

// ------------------------------------------
// REQUIRE
require 'script.php';
require 'outro.php';    // o ficheiro não existe. Vai aparecer um erro.
require 'script.php';
