<?php

// INCLUDE e REQUIRE

/* 
include_once e require_once efetuam a inclusão do script apenas uma vez.
Se o script foi anteriormente carregado, já não vai ser mais carregado.
*/

include_once 'script.php';
include_once 'script.php';

require_once 'script.php';
require_once 'script.php';
