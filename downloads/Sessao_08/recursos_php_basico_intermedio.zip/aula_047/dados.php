<?php

return [
    'joao', 'ana', 'carlos','antónio','sara','maria'
];