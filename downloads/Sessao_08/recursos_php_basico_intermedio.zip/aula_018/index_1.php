<?php

    // INTEIROS (INT)

    // são números sem casas decimais, positivos, negativos ou o zero
    
    $valor1 = 100;
    $valor2 = 2347862;
    $valor3 = 0;
    $valor4 = -1265;

    // em sistemas de 32 bits e 64 bits, temos
    // limites máximos e mínimos diferentes
    
    // podemos ver os limites usando constantes nativas do PHP
    echo PHP_INT_MIN . '<br>';
    echo PHP_INT_MAX . '<br>';