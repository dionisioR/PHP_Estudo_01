<?php

// EXEMPLO PRÁTICO DO USO DE INCLUSÃO DE SCRIPTS

/* 
Muitas vezes o include e require é usado para não duplicar código.
Vejamos os exemplos 1 e 2.
*/