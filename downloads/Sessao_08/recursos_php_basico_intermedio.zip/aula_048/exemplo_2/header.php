<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo 2</title>
</head>
<body>
    
    <nav>
        <a href="index.php">Início</a> | 
        <a href="about.php">Acerca de</a> | 
        <a href="contact.php">Contacto</a> | 
    </nav>