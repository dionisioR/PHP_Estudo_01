<?php require_once('header.php') ?>
<h1>Contactos</h1>
<hr>
<p>Os meus contactos</p>
<?php require_once('footer.php') ?>
