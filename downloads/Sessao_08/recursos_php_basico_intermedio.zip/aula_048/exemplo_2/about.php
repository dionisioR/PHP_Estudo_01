<?php require_once('header.php') ?>
<h1>Acerca de</h1>
<hr>
<p>Página acerca de mim</p>
<?php require_once('footer.php') ?>