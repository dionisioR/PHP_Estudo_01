<?php require_once('header.php') ?>
<h1>Início</h1>
<hr>
<p>Página inicial</p>
<?php require_once('footer.php') ?>