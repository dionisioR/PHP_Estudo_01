// ARRAYS

// -------------------------------
// até agora...
// -------------------------------
let nome1 = "joao"
let nome2 = "ana"
let nome3 = "carlos"

// com um array...
let nomes = ["joao", "ana", "carlos"]


// -------------------------------
// apresentar dados de um array
// -------------------------------
// console.log(nomes)      // todos os elementos
// console.log(nomes[1])   // ana
// console.table(nomes)

// -------------------------------
// alterar dados de um array
// -------------------------------
// nomes[1] = "maria"
// console.table(nomes)