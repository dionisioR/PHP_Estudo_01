let condicao_do_tempo = 'sol'

if(condicao_do_tempo == 'sol'){
    console.log('Está bom tempo para um passeio.')
}