// STRINGS

let nome = 'Joao'
let apelido = "Ribeiro"

let frase1 = "O bar chama-se John's House."
let frase2 = 'Alguém disse "Vitoria"'
let frase3 = 'Esta string está mal definida"

let frase4 = 'O bar chama-se John\'s House.'