/*
document.getElementsByClassName()
document.getElementsByName()
document.getElementsByTagName()
*/
