<?php

define('APP_NAME',  'App Name');

// database
define('MYSQL_HOST',        '');
define('MYSQL_DATABASE',    '');
define('MYSQL_USERNAME',    '');
define('MYSQL_PASSWORD',    '');

define('MYSQL_AES_KEY',     '');

// logs
define('LOGS_PATH',         __DIR__ . '/../logs/app.log');

// openssl
define('OPENSSL_KEY',       'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
define('OPENSSL_IV',        'yyyyyyyyyyyyyyyy');