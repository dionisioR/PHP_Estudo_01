<?php defined('CONTROL') OR die('Acesso inválido'); ?>
<!-- navegacao -->
<div class="center">
    <h2>
        <a href="index.php">Início</a>&nbsp;|&nbsp;
        <a href="index.php?a=1">Página 1</a>&nbsp;|&nbsp;
        <a href="index.php?a=2">Página 2</a>&nbsp;|&nbsp;
        <a href="index.php?a=3">Página 3</a>
    </h2>
</div>