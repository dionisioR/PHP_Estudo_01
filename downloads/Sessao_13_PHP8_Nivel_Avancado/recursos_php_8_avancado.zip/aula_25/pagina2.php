<?php defined('CONTROL') OR die('Acesso inválido'); ?>
<hr>
<h1 class="center">Página 2</h1>
