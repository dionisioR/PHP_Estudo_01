<?php defined('CONTROL') OR die('Acesso inválido'); ?>
<hr>
<h1 class="center">Página 3</h1>
