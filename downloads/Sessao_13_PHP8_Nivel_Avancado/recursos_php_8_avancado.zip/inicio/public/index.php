<?php

echo 'index.php';