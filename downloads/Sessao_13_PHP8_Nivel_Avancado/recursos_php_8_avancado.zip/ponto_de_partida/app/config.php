<?php

define('APP_NAME',  'Basic Name Gathering');

// database
define('MYSQL_HOST',        'localhost');
define('MYSQL_DATABASE',    'db_bng');
define('MYSQL_USERNAME',    'user_db_bng');
define('MYSQL_PASSWORD',    '3LduNkJe55lVk0iaQRXvV0j1tZpA7OW5');