<script src="assets/bootstrap/bootstrap.bundle.min.js"></script>
<script src="assets/app.js"></script>
</body>
</html>