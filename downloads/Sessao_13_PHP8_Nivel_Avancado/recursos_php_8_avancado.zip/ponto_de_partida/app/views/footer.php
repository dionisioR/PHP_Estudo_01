<div class="fixed-bottom footer p-3 text-center">
    <?= APP_NAME ?> &copy; <?= date("Y") ?> Todos os direitos reservados.
</div>