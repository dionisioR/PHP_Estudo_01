
## IMPORTANTE
===================================

align
bgcolor
border
cellpadding
cellspacing
frame
rules
summary
width

Apenas estão disponíveis para retrocompatibilidade e não devem ser usados.
Todos os estilos devem ser aplicados via CSS.

## NOTA: Excepção para tabelas usadas em HTML para envio de emails.
