<?php

// COMO ESCREVER UMA CLASSE E INSTANCIAR UM OBJETO

/* 
Vimos que uma classe é um modelo para criar objetos.
Os objetos, são instâncias de uma classe.
Já vamos perceber tudo isso de forma simples.
*/

// Como criar uma classe?

class Fruto
{

    // código da classe aqui dentro ...

}

// como criar um objeto a partir dessa classe?

$laranja = new Fruto();
