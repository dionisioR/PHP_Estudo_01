<?php

// Existe uma forma de simplificar a identificação dos namespaces
// que vamos usar na nossa aplicação.

namespace Estrutuas_principais;

class Loja
{
    // ...
}

class Armazem
{
    // ...
}
