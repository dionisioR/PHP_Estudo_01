<?php

namespace Armazem;

class Operacoes
{
    public function operacao_1()
    {
        echo 'Operacao_1 das operações do armazém<br>';
    }
    
    public function operacao_2()
    {
        echo 'Operacao_2 das operações do armazém<br>';
    }
}