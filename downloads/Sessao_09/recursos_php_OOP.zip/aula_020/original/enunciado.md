# exercício 4
------------------------------------------------------------
Partindo do código do exercício anterior, neste exercício
deves apresentar todos os veículos cujo ano de fabrico seja
anterior a 2015, inclusive.
