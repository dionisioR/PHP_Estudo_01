<?php

class Humano
{
    public $nome;
    public $apelido;
}