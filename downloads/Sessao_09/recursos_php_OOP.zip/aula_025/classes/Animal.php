<?php

class Animal
{
    public $especie;
    public $nome;
}